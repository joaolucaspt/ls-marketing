/* eslint-disable */

// @ts-nocheck

// noinspection JSUnusedGlobalSymbols

// Hand-maintained after converting the project to a plain client-side SPA
// (removed the TanStack Start server-only "/sitemap.xml" route — it is now
// a static file at public/sitemap.xml instead).

import { Route as rootRouteImport } from './routes/__root'
import { Route as PoliticaDePrivacidadeRouteImport } from './routes/politica-de-privacidade'
import { Route as IndexRouteImport } from './routes/index'

const PoliticaDePrivacidadeRoute = PoliticaDePrivacidadeRouteImport.update({
  id: '/politica-de-privacidade',
  path: '/politica-de-privacidade',
  getParentRoute: () => rootRouteImport,
} as any)
const IndexRoute = IndexRouteImport.update({
  id: '/',
  path: '/',
  getParentRoute: () => rootRouteImport,
} as any)

export interface FileRoutesByFullPath {
  '/': typeof IndexRoute
  '/politica-de-privacidade': typeof PoliticaDePrivacidadeRoute
}
export interface FileRoutesByTo {
  '/': typeof IndexRoute
  '/politica-de-privacidade': typeof PoliticaDePrivacidadeRoute
}
export interface FileRoutesById {
  __root__: typeof rootRouteImport
  '/': typeof IndexRoute
  '/politica-de-privacidade': typeof PoliticaDePrivacidadeRoute
}
export interface FileRouteTypes {
  fileRoutesByFullPath: FileRoutesByFullPath
  fullPaths: '/' | '/politica-de-privacidade'
  fileRoutesByTo: FileRoutesByTo
  to: '/' | '/politica-de-privacidade'
  id: '__root__' | '/' | '/politica-de-privacidade'
  fileRoutesById: FileRoutesById
}
export interface RootRouteChildren {
  IndexRoute: typeof IndexRoute
  PoliticaDePrivacidadeRoute: typeof PoliticaDePrivacidadeRoute
}

declare module '@tanstack/react-router' {
  interface FileRoutesByPath {
    '/politica-de-privacidade': {
      id: '/politica-de-privacidade'
      path: '/politica-de-privacidade'
      fullPath: '/politica-de-privacidade'
      preLoaderRoute: typeof PoliticaDePrivacidadeRouteImport
      parentRoute: typeof rootRouteImport
    }
    '/': {
      id: '/'
      path: '/'
      fullPath: '/'
      preLoaderRoute: typeof IndexRouteImport
      parentRoute: typeof rootRouteImport
    }
  }
}

const rootRouteChildren: RootRouteChildren = {
  IndexRoute: IndexRoute,
  PoliticaDePrivacidadeRoute: PoliticaDePrivacidadeRoute,
}
export const routeTree = rootRouteImport
  ._addFileChildren(rootRouteChildren)
  ._addFileTypes<FileRouteTypes>()
